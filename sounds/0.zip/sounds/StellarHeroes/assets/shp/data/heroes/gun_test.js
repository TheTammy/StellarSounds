function init(hero) {
    hero.setName("Test");
    hero.setTier(3);

    hero.setChestplate("Suit");
}