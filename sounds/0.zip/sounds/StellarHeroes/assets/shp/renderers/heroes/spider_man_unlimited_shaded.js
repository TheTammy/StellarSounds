extend("shp:spider_man_unlimited");
loadTextures({
    "base": "shp:spider_man_unlimited_shaded",
    "suit": "shp:spider_man_unlimited_shaded_suit.tx.json",
    "mask": "shp:spider_man_unlimited_mask_shaded.tx.json"
});